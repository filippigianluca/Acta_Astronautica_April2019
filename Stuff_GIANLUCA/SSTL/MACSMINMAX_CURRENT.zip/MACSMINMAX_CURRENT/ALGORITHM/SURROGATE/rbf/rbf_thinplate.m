function psi = rbf_thinplate(r,s)

psi = r.^2.*log(r);

end
