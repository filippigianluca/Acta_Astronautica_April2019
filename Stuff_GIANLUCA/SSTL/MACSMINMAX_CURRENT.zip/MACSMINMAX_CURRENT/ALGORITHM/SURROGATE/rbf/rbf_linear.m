function [psi,dpsi] = rbf_linear(r,s)

psi = r;
dpsi = ones(size(psi));

end
